package com.example.lkspractice

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.json.JSONObject

class SignInActivity : AppCompatActivity() {
    private lateinit var tvUsername: TextView
    private lateinit var tvPassword: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        tvUsername = findViewById(R.id.tv_username)
        tvPassword = findViewById(R.id.tv_password)

        val backBtn = findViewById<Button>(R.id.btn_back)
        val loginBtn = findViewById<Button>(R.id.btn_login)

        backBtn.setOnClickListener {
            val intent = Intent(this, FirstActivity::class.java)
            startActivity(intent);
        }

        loginBtn.setOnClickListener{
            checkLogin()
        }


    }

    private fun checkLogin() {

        val username = tvUsername.text.toString()
        val password = tvPassword.text.toString()
        if(username.isEmpty() || password.isEmpty()) {
            alert("Tolong lengkapi Field!", false)
        } else {
            sendLogin()
        }
    }

    private fun sendLogin() {
        val params = JSONObject()
        try {
            params.put("usernameOrEmail", tvUsername.text.toString())
            params.put("password", tvPassword.text.toString())
        } catch (err: Exception) {
            err.printStackTrace()
            Log.d("MY DEBUG", err.toString())
        }
        Log.d("MY DEBUG", "BERHASIL!")
        val data: String = params.toString()
        val url = "${getString(R.string.api_server)}api/sign-in"

        Thread(Runnable {
            run {
                val http = Http(this@SignInActivity, url)
                http.setMethod("POST")
                http.setData(data)
                http.send()
                runOnUiThread(Runnable {
                    run {
                        val statusCode: Int = http.getStatusCode()
                        val response: String? = http.getResponse()

                        Log.d("MY DEBUG", statusCode.toString())

                        if(statusCode == 500) {
                            alert("Internal Server Error", false)
                        }

                        if(statusCode == 404) {
                            alert("User tidak ditemukan", false)
                        }

                        if(statusCode in 200..299) {
                            val intent = Intent(this@SignInActivity, MainActivity::class.java).apply {
                                putExtra("data", response) // Titip "data": response, untuk dibawa ke Main Activity
                            }
                            startActivity(intent)
                            finish()
                        }
                    }
                })
            }
        }).start()
    }

    private fun alert(message: String, type: Boolean) {

        if (type) {
        AlertDialog.Builder(this).setTitle("SUCCESS!").setMessage(message).setPositiveButton("OK", DialogInterface.OnClickListener() {
            dialogInterface: DialogInterface?, i: Int -> dialogInterface?.dismiss()
        }).show()
        } else {
            AlertDialog.Builder(this).setTitle("OOPS!").setMessage(message).setPositiveButton("OK", DialogInterface.OnClickListener() {
                    dialogInterface: DialogInterface?, i: Int -> dialogInterface?.dismiss()
            }).show()
        }

    }

    fun goToSignUpActivity(view: View) {
        intent = Intent(this, SignUpActivity::class.java)
        startActivity(intent)
        finish()
    }
}