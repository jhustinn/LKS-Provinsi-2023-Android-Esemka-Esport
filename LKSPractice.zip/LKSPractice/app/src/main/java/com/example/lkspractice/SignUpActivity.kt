package com.example.lkspractice

import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import org.json.JSONException
import org.json.JSONObject
import java.lang.Exception
import java.lang.StringBuilder
import java.util.regex.Matcher
import java.util.regex.Pattern

class SignUpActivity : AppCompatActivity() {

    private lateinit var btnBack: Button
    private lateinit var btnSignUp: Button

    private lateinit var tvFullName: EditText
    private lateinit var tvUsername: EditText
    private lateinit var tvEmail: EditText
    private lateinit var tvPhoneNumber: EditText
    private lateinit var tvPassword: EditText

    private lateinit var fullName: String
    private lateinit var username: String
    private lateinit var email: String
    private lateinit var phoneNumber: String
    private lateinit var password: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        btnBack = findViewById(R.id.btn_back)
        btnSignUp = findViewById(R.id.btn_signUp)

        tvUsername = findViewById(R.id.tvUsername)
        tvEmail = findViewById(R.id.tvEmail)
        tvPassword = findViewById(R.id.tvPassword)
        tvFullName = findViewById(R.id.tvFullName)
        tvPhoneNumber = findViewById(R.id.tvPhoneNumber)

        btnBack.setOnClickListener{
            intent = Intent(this, FirstActivity::class.java)
            startActivity(intent);
        }

        btnSignUp.setOnClickListener{
            checkReq()
        }
    }

    private fun checkReq() {
        username = tvUsername.text.toString()
        fullName = tvFullName.text.toString()
        email = tvEmail.text.toString()
        phoneNumber = tvPhoneNumber.text.toString()
        password = tvPassword.text.toString()
        if(username.isEmpty() || fullName.isEmpty() || email.isEmpty() || phoneNumber.isEmpty() || password.isEmpty()) {
            alert("Tolong isi semua Field!", false)
        } else if (username.length < 6 || password.length < 6) {
            alert("Minimal panjang username dan password adalah 6 char!", false)
        } else {
            val pattern: Pattern = Pattern.compile("\\d{10,13}")
            val matcher: Matcher = pattern.matcher(phoneNumber)
            if(!matcher.matches()) {
                alert("Phone Number harus berisi valid no HP!", false)
            } else {
            sendReq()
            }
        }
    }

    private fun sendReq() {
        val params = JSONObject()
        try {
            params.put("fullName", fullName)
            params.put("username", username)
            params.put("email", email)
            params.put("phoneNumber", phoneNumber)
            params.put("password", password)
        } catch (err: JSONException) {
            err.printStackTrace()
            Log.d("JSONException sendReq()", err.toString())
        }

        val data: String = params.toString()
        val url: String = "${getString(R.string.api_server)}api/sign-up"


        Thread(Runnable {
            run {
                val http = Http(this, url)
                http.setMethod("POST")
                http.setData(data)
                http.send()
                runOnUiThread(Runnable {
                    run {
                        val statusCode: Int = http.getStatusCode()
                        val response: String? = http.getResponse()
                        val jsonObject = JSONObject(response)
                        val errorMessageBuilder = StringBuilder()

                        if(statusCode == 409) {
                            try {

                                if(jsonObject.has("username")) {
                                    errorMessageBuilder.append(jsonObject.getJSONArray("email").getString(0)).append("\n")
                                } else if (jsonObject.has("email")) {
                                    errorMessageBuilder.append(jsonObject.getJSONArray("username").getString(0)).append("\n")
                                }
                                alert(errorMessageBuilder.toString(), false)
                            } catch (err: JSONException) {
                                err.printStackTrace()
                                Log.d("JSON EXCEPTION 409 sendReq", err.toString())
                            }
                        } else if (statusCode == 400) {
                            try {
                                val errors = jsonObject.getJSONObject("errors")

                                var keys: Iterator<String> = errors.keys()

                                while (keys.hasNext()) {
                                    val key: String = keys.next()
                                    val errorMessages = errors.getJSONArray(key)

                                    for (i in 0 until errorMessages.length()) {
                                        val errorMessage = errorMessages.getString(i)
                                        errorMessageBuilder.append(errorMessage).append("\n")
                                    }
                                }
                                alert(errorMessageBuilder.toString(), false);
                            } catch (err: JSONException) {
                                err.printStackTrace()
                                Log.d("JSON EXCEPTION 400 sendReq", err.toString())
                            }
                        } else if (statusCode == 201) {
                            intent = Intent(this, SignInActivity::class.java)
                            startActivity(intent)
                            finish()

                            val text: CharSequence = "Akun Berhasil Dibuat! Silahkan login."
                            val duration: Int = Toast.LENGTH_SHORT
                            val toast = Toast.makeText(this, text, duration)
                            toast.show()
                        } else {
                            alert("Internal server error!", false)
                        }
                    }
                })
            }
        }).start()
    }

    private fun alert(message: String, type: Boolean) {
         if(type) {
             AlertDialog.Builder(this).setTitle("SUCCESS!").setMessage(message).setPositiveButton("OK", DialogInterface.OnClickListener() {
                     dialogInterface:  DialogInterface?, _ -> dialogInterface?.dismiss()
             }).show()
         } else {
        AlertDialog.Builder(this).setTitle("OOPS!").setMessage(message).setPositiveButton("OK", DialogInterface.OnClickListener() {
            dialogInterface:  DialogInterface?, _ -> dialogInterface?.dismiss()
        }).show()
         }
    }

    fun goToSignInActivity(view: View) {
        intent = Intent(this, SignInActivity::class.java)
        startActivity(intent)
        finish()
    }

}