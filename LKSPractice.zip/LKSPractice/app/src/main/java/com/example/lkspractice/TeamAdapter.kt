package com.example.lkspractice

class TeamAdapter {
}