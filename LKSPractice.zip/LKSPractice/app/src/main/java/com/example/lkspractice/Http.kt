package com.example.lkspractice

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.lang.Exception
import java.net.HttpURLConnection
import java.net.URL

class Http(private val context: Context, private val url :String) {

    private var method = "GET"
    private var response :String? = null
    private var data :String? = null
    private var statusCode :Int = 0;

//    private var myUrl: String = "http://10.0.2.2:5000/"

    fun setMethod(method: String) { this.method = method }

    fun setData(data: String) { this.data = data }

    fun getResponse() :String? { return response }

    fun getStatusCode() :Int { return statusCode }

    fun send() {
        try {
            val sUrl = URL(url)
            val conn = sUrl.openConnection() as HttpURLConnection

            Log.d("CONN", conn.toString())
            conn.requestMethod = method
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept","application/json")
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")

            if(method != "GET") {
                conn.doOutput = true
            }

            if(data != null) {
                val outputStream :OutputStream = conn.outputStream
                outputStream.write(data!!.toByteArray())
                outputStream.flush()
                outputStream.close()
            }

            statusCode = conn.responseCode

            Log.d("MY DEBUG HTTP", statusCode.toString())

            val inputStreamReader: InputStreamReader
            if(statusCode in 200..299) {
                inputStreamReader = InputStreamReader(conn.inputStream)
            } else {
                inputStreamReader = InputStreamReader(conn.errorStream)
            }

            val bufferedReader = BufferedReader(inputStreamReader)
            val stringBuffer= StringBuffer()
            var line: String?
            while (bufferedReader.readLine().also { line = it } != null){
                stringBuffer.append(line)
            }

            bufferedReader.close()
            response = stringBuffer.toString()

        } catch (err :Exception) {
            err.printStackTrace()
            Log.d("MY SEND", err.toString())
        }
    }
}