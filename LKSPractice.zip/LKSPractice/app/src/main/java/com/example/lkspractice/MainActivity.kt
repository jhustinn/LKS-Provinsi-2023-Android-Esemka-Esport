package com.example.lkspractice

import android.content.DialogInterface
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.json.JSONException
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity: AppCompatActivity() {

    private lateinit var tvTime: TextView
    private val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy hh:mm:ss a", Locale.getDefault())
    private val handler = Handler()
    private val updateTimeTask = object : Runnable {
        override fun run() {
            updateCurrentTime()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Ambil data dari intent sebelum nya
        val data = intent.getStringExtra("data")

        val tvHalo = findViewById<TextView>(R.id.tvHalo)
        tvTime = findViewById(R.id.tvTime)

        val tabTim = findViewById<TextView>(R.id.tabTim)
        val tabPlayer = findViewById<TextView>(R.id.tabPlayer)

        val teamFragment = TeamFragment()
        val playerFragment = PlayerFragment()

        val defaultColor = resources.getColor(R.color.purple)

        // Run Live Timer
        startUpdateTimer()

        try {
            val jsonObject = JSONObject(data)
            val fullName = jsonObject.getString("fullName")
            tvHalo.text = "Halo, ${fullName}"
        }
        catch (err: JSONException) {
            err.printStackTrace()
            alert(err.toString())
        }


        // set halaman pertama yang dibuka
        tabTim.setBackgroundColor(resources.getColor(android.R.color.white))
        tabTim.setTextColor(resources.getColor(android.R.color.black))
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.container, teamFragment)
            commit()
        }

        // event listener tab to open fragment
        tabTim.setOnClickListener{
            tabTim.setBackgroundColor(resources.getColor(android.R.color.white))
            tabTim.setTextColor(resources.getColor(android.R.color.black))
            tabPlayer.setTextColor(resources.getColor(android.R.color.white))
            tabPlayer.setBackgroundColor(defaultColor)
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.container, teamFragment)
                commit()
            }
        }
        tabPlayer.setOnClickListener{
            tabPlayer.setBackgroundColor(resources.getColor(android.R.color.white))
            tabTim.setTextColor(resources.getColor(android.R.color.white))
            tabPlayer.setTextColor(resources.getColor(android.R.color.black))
            tabTim.setBackgroundColor(defaultColor)
            supportFragmentManager.beginTransaction().apply {
                replace(R.id.container, playerFragment)
                commit()
            }
        }
    }

    private fun alert(message: String) {
        AlertDialog.Builder(this).setTitle("SUCCESS!").setMessage(message).setPositiveButton("OK", DialogInterface.OnClickListener() {
                dialogInterface: DialogInterface?, i: Int -> dialogInterface?.dismiss()
        }).show()
    }

    // Live Date
    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateTimeTask) // Hentikan pembaruan waktu saat aktivitas dihancurkan
    }

    private fun startUpdateTimer() {
        handler.postDelayed(updateTimeTask, 0) // Memulai pembaruan waktu secara terus menerus
    }

    private fun updateCurrentTime() {
        val currentDate = Date()
        val formattedDate = dateFormat.format(currentDate)
        tvTime.text = formattedDate
    }

    // Fetch Data
    class FetchData {
         fun doInBackground(vararg p0: Void?): Void {
            TODO("Not yet implemented")
        }

    }
}

