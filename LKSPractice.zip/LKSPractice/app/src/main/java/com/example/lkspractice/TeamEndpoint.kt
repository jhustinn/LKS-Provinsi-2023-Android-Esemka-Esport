package com.example.lkspractice

class TeamEndpoint {
}